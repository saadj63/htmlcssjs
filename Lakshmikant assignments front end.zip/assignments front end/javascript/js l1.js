var first=prompt("enter your first name");
var last=prompt("enter your last name");
var age=prompt("enter your age ");
var height=prompt("enter your height ");
var pet=prompt("enter your pet name");

var f,a,h,p

if (first[0]==last[0]) {
    f=true;
} else {
    f=false;
}
if (age>20&& age<30) {
    a=true;
} else {
    a=false;
}
if (height>=175) {
    h=true;
} else {
    h=false;
}

if (pet[pet.length-1]=='y') {
    p=true;
} else {
    p=false;
}

if (f&&a&&h&&p) {
    console.log("you have passed");
} else {
    console.log("you have failed");
}